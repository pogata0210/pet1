package com.example.pablo.pet1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

        TextView   dogText;
        TextView    catText;
        TextView    lionText;
        TextView    petsText;
        TextView    niceText;
        TextView    pandaText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        petsText = (TextView)  findViewById(R.id.pets_text);
        petsText.setTextColor(Color.BLUE);
        dogText = (TextView) findViewById(R.id.dog_text);
        catText = (TextView) findViewById(R.id.cat_text);
        lionText = (TextView) findViewById(R.id.lion_textion_text);
        niceText = (TextView) findViewById(R.id.nice_text_text);
        niceText.setTextColor(Color.BLUE);
        pandaText = (TextView) findViewById(R.id.panda_text);

    }
}
